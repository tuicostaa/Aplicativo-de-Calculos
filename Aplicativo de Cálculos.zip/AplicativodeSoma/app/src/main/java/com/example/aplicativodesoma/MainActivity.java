package com.example.aplicativodesoma;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnTela;
    Button btnimc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    btnTela = findViewById(R.id.btntela);
    btnTela.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent CalculoSimples = new Intent( getApplicationContext(), CalculoSimples.class);
            startActivity( CalculoSimples);
        }
    });

    btnimc = findViewById(R.id.btnimc);
    btnimc.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent CalculoIndice = new Intent( getApplicationContext(), CalculoIndice.class);
            startActivity( CalculoIndice);
            }
        });

    btnbhask = findViewById(R.id.btnbhask);
    btnbhask.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent CalculoBhaskara = new Intent( getApplicationContext(), CalculoBhaskara.class);
            startActivity( CalculoBhaskara);
            }
        });
    }
}



