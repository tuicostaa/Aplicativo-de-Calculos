package com.example.aplicativodesoma;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
public class CalculoIndice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EditText edtpeso = findViewById(R.id.edtpeso);
        Double peso = Double.parseDouble(edtpeso.getText().toString());

        EditText edtaltura = findViewById(R.id.edtaltura);
        Double altura = Double.parseDouble(edtaltura.getText().toString());

        Double imc = peso/(altura*altura);

        TextView txtimc = findViewById(R.id.txtimc);
        txtimc.setText(Double.toString(imc));

        TextView txtsitu = findViewById(R.id.txtsitu);
        if(imc<17)
        {
            String resultado = "Muito Abaixo do Peso";
            txtsitu.setText(resultado);
        }else if(imc >=17&&imc< 18.5)
        {
            String resultado = "Abaixo do Peso";
            txtsitu.setText(resultado);
        }else if(imc >=18.5&&imc< 25)
        {
            String resultado = "Peso Normal";
            txtsitu.setText(resultado);
        }else if(imc >=25&&imc< 30)
        {
            String resultado = "Acima do Peso";
            txtsitu.setText(resultado);
        }else if(imc >=30&&imc< 35)
        {
            String resultado = "Obesidade I";
            txtsitu.setText(resultado);
        }else if(imc >=35&&imc< 40)
        {
            String resultado = "Obesidade II";
            txtsitu.setText(resultado);
        }else
        {
            String resultado = "Obesidade III";
            txtsitu.setText(resultado);
        }

        setContentView(R.layout.activity_calculo_indice);
    }

    }