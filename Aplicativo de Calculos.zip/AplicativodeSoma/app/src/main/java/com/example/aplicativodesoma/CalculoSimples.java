package com.example.aplicativodesoma;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculoSimples extends AppCompatActivity {

    Button btnSoma;
    TextView txtresultado;
    EditText txt1, txt2, txt3;
    Integer num1, num2, num3, soma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_simples);

        btnSoma = findViewById(R.id.btnsoma);
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText txt1 = findViewById(R.id.txt1);
                EditText txt2 = findViewById(R.id.txt2);
                EditText txt3 = findViewById(R.id.txt3);

                Integer num1 =Integer.parseInt(txt1.getText().toString());
                Integer num2 =Integer.parseInt(txt2.getText().toString());
                Integer num3 =Integer.parseInt(txt3.getText().toString());

                Integer soma = num1+num2+num3;

                TextView txtresultado = findViewById(R.id.txtresultado);
                txtresultado.setText(Integer.toString(soma));
            }
        });
    }
}
